
Mario & Luigi: Superstar Saga Styled Balloon

This balloon is not part of a ghost/ukagaka.


-------- Version History --------

 Version 0.0.1 
   - Started balloon.

 Version 0.0.2
   - Finished input boxes.
   - Added small balloons.
   - Made custom 'confirm' and 'cancel' buttons for the input boxes.
   - Finished descript.txt
   - Made the thumbnail.png

 Version 0.0.3 
   - Edited the small Balloons.
   - Edited descript.txt

 Version 1.0.0 (5/20/2018)
   - Official Release

 Version 1.0.1 (2/5/2021)
   - Minor tweaks
   - added the necessary font...

 Version 1.0.2 (2/18/2021)
   - Removed font for individual download.
   - Added site source link.
   - Removed empty profile folder.
   - Minor coding and comment tweaks.

 Version 1.0.3 (8/24/2021)
   - Added link to site of origin.
   - Added back profile folder, just in case.