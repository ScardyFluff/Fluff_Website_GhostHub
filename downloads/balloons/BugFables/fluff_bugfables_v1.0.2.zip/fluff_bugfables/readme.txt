Bug Fables: The Everlasing Sapling Styled Balloon

Link to Font: https://fonts.google.com/specimen/Bubblegum+Sans

------- Version History -------

Version 1.0.0 (5/20/2020)
 - Official Release

Version 1.0.1 (4/26/2021)
 - Renamed to just Bug Fables
 - Added link to font in Readme

Version 1.0.2 (8/24/2021)
 - Added link to site of origin.