Mario and Luigi: Superstar Saga Style Balloon.

This balloon is not part of a ghost/ukagaka.


--------Version History

Ver 0.1 
 - Started balloon.

Ver 0.2
 - Finished input boxes.
 - Added small balloons.
 - Made custom 'confirm' and 'cancel' buttons for the input boxes.
 - Finished descript.txt
 - Made the thumbnail.png

Ver 0.3 
 - Edited the small Balloons.
 - Edited descript.txt

Ver 1.0 (5/20/18)
 - Official Release